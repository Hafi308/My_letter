const message = `Dear You 🌸

If you're reading this, thank you for opening this little surprise.

I just wanted to say that you are truly appreciated.

Your kindness, your smile, and the way you treat others make a bigger difference than you probably realize.

I don't expect anything in return.
I simply wanted you to know that you are special, valued, and someone worth appreciating.

Whenever life feels difficult, I hope you remember this...

✨ You are enough.
✨ You are appreciated.
✨ Keep smiling.

Take care of yourself.

— Someone who truly appreciates you. 💖`;

function openLetter() {
    document.getElementById("home").style.display = "none";
    document.getElementById("letter").style.display = "block";

    let i = 0;
    const typing = document.getElementById("typing");

    function type() {
        if (i < message.length) {
            typing.innerHTML += message.charAt(i);
            i++;
            setTimeout(type, 35);
        }
    }

    type();
}

// Floating Hearts
setInterval(() => {
    const heart = document.createElement("div");
    heart.className = "heart";
    heart.innerHTML = "💖";
    heart.style.left = Math.random() * 100 + "vw";
    heart.style.fontSize = (20 + Math.random() * 20) + "px";

    document.body.appendChild(heart);

    setTimeout(() => {
        heart.remove();
    }, 8000);

}, 500);